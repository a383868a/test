<template>
    <Form ref="formValidate" :model="formValidate" :rules="ruleValidate" :label-width="80">       
        <FormItem label="ToDo" prop="todo">
            <Input v-model="formValidate.todo" placeholder="Enter something"></Input>
        </FormItem>
        <FormItem label="StartDate">
            <Row>
                <Col span="11">
                    <FormItem prop="date">
                        <DatePicker type="date" placeholder="Select date" v-model="formValidate.date"></DatePicker>
                    </FormItem>
                </Col>
                <Col span="2" style="text-align: center">-</Col>
                <Col span="11">
                    <FormItem prop="time">
                        <TimePicker type="time" placeholder="Select time" v-model="formValidate.time"></TimePicker>
                    </FormItem>
                </Col>
                <Button type="error" size="small" @click="getTodo">getTodo</Button>
            </Row>
        </FormItem>
         <FormItem label="EndDate">
            <Row>
                <Col span="11">
                    <FormItem prop="date">
                        <DatePicker type="date" placeholder="Select date" v-model="formValidate.date1"></DatePicker>
                    </FormItem>
                </Col>
                <Col span="2" style="text-align: center">-</Col>
                <Col span="11">
                    <FormItem prop="time">
                        <TimePicker type="time" placeholder="Select time" v-model="formValidate.time1"></TimePicker>
                    </FormItem>
                </Col>
               {{all}} 
            </Row>
        </FormItem>
        <FormItem>
            <Button type="primary" @click="handleSubmit('formValidate'), push()">Submit</Button>
            <Button @click="handleReset('formValidate')" style="margin-left: 8px">Reset</Button>
        </FormItem>
        <Table border :columns="columns12" :data="all">
        <template slot-scope="{ row }" slot="name">
            <strong>{{ row.name }}</strong>
        </template>
        <template slot-scope="{ row, index }" slot="action">
            <Button type="primary" size="small" style="margin-right: 5px" @click="show(index)">View</Button>
            <Button type="error" size="small" @click="remove(index)">Delete</Button>
        </template>
    </Table>
    </Form>


</template>
<script>
    import axios from 'axios';

    export default {
        data () {
            return {
                
                formValidate: {
                    item: '',
                    date: '',
                    time: '',
                    date1: '',
                    time1: '',
                },
                ruleValidate: {
                    item: [
                        { required: true, message: 'You need to write something', trigger: 'blur' }
                    ],

                    date: [
                        { required: true, type: 'date', message: 'Please select the date', trigger: 'change' }
                    ],
                    time: [
                        { required: true, type: 'string', message: 'Please select time', trigger: 'change' }
                    ],
                    date1: [
                        { required: true, type: 'date', message: 'Please select the date', trigger: 'change' }
                    ],
                    time1: [
                        { required: true, type: 'string', message: 'Please select time', trigger: 'change' }
                    ]
                   
                },  
                columns12: [
                    {
                        title: 'Item',
                        slot: 'item'
                    },
                    {
                        title: 'StartDate',
                        key: 'date'
                    },
                    {
                        title: 'StartTime',
                        key: 'time1'
                    },
                    {
                        title: 'EndDate',
                        key: 'date1'
                    },
                    {
                        title: 'EndTime',
                        key: 'time1'
                    },
                    {
                        title: 'Action',
                        slot: 'action',
                        width: 150,
                        align: 'center'
                    }
                ],
                data6: [
                    {
                        item: 'hi',
                        date: 18,
                        time: 2,
                        date1: 'New York No. 1 Lake Park',
                        time1: 2
                    },
                    {
                        item: 'Jim Green',
                        date: 24,
                        time: 2,
                        date1: 'New York No. 1 Lake Park',
                        time1: 2
                    },
                    {
                        item: 'Joe Black',
                        date: 30,
                        time: 2,
                        date1: 'New York No. 1 Lake Park',
                        time1: 2
                    },
                    {
                        item: 'Jon Snow',
                        date: 26,
                        time: 2,
                        date1: 'New York No. 1 Lake Park',
                        time1: 2
                    }
                ],
                all:[],
               
            }
        },
        methods: {
            push(){
                    this.all.push(this.formValidate)
                    stop
                },
            handleSubmit (item) {
                this.$refs[item].validate((valid) => {
                    if (valid) {
                        this.$Message.success('Success!');
                    } else {
                        this.$Message.error('Fail!');
                    }
                })
            },
            handleReset (item) {
                this.$refs[item].resetFields();
            },
            show (index) {
                this.$Modal.info({
                    title: 'User Info',
                    content: `Item：${this.all[index].item}<br>Date：${this.all[index].date}<br>Time：${this.all[index].time}`
                })
            },
            remove (index) {
                this.all.splice(index, 1);
            },

            getTodo: async function(payload) {
                let result = await axios.get("/todo", payload);
                console.log(result);
                return result.data.body;
            }
        }
     
    }
</script>
   
            
    
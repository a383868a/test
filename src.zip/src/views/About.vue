<template>
  <div class="about">
    <h1>Calculator</h1>
     <br><br> 
    <input type="text" v-model="result" />
   <br><br> 
    <NumericKeyboard @on-click="NumberMsg" @click="plus()" ></NumericKeyboard>

  </div>
</template>
<script>
// @ is an alias to /src
import NumericKeyboard from '@/components/NumericKeyboard.vue'


export default {
  name: 'about',
  components: {
    NumericKeyboard
  },
  data(){
    return{
     result :"",
      } 
  },
  methods:{  
    NumberMsg: function (val) { 
      console.log(this.result);
      if(val == '='){
        this.result = eval(this.result); 
        return
      }
      if(val == 'AC'){
        this.result = ""; 
        return
      }
      this.result += val
    },
  
  }
}
</script>
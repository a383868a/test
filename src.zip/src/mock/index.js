import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';

// 设置模拟调试器实例 
var mock = new MockAdapter(axios);
// 模拟任意GET请求到 /users 
//reply的参数为 (status, data, headers) 
mock.onGet('/todo').reply(200, {
users: [
    { id: 1, name: 'John Smith' }
]
});